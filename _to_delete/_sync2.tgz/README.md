# Flow control benchmarks for llm-d

Flow control is the Endpoint Picker's policy layer for multi-tenant inference. While the GPU has capacity, requests pass straight through. When the pool comes under pressure, flow control activates, and new work waits in policy-aware queues in front of vLLM, so priority, fairness, and traffic class decide what runs next instead of arrival order.

This repo holds the measured evidence, the charts drawn from it, the per-request data, and the runner that produced it. Everything ran on one GPU serving GPT-OSS 20B behind the llm-d inference gateway.

<img src="assets/results-at-a-glance.svg" width="100%" alt="Results at a glance: consolidation held 45 to 69 ms p95 TTFT, premium ran 41 ms against standard 379 ms, batch queued 202 ms against premium 64 ms, and the capacity envelope spread from 569 ms to 6.0 s at 160 concurrent">

**How to read the numbers.** The pool is one GPU, so the absolute latencies track that hardware and tuning. The pattern is the finding. The target held during consolidation, priority ordered the queue under saturation, and batch absorbed the waiting. On different hardware the numbers move and the behavior stays.

<img src="assets/dispatch-path.svg" width="100%" alt="Dispatch path: the gateway tags requests, the Endpoint Picker queues by priority band with round-robin fairness and a saturation gate, then dispatches to vLLM">

## The capacity envelope

Before any scenario, we swept the pool to learn its shape. Five request shapes, from short interactive to long generation, each stepped from 16 to 160 concurrent requests.

**What it proves.** Concurrency alone does not describe load. Every shape first showed vLLM waiting requests at 160 concurrent, and the cost of operating there ranged from 569 ms p95 TTFT at 165 requests per second to 6.0 s at 27 requests per second.

<img src="assets/capacity-envelope.svg" width="100%" alt="p95 TTFT by concurrency for five request shapes, all first queueing at 160 concurrent with an order of magnitude spread in cost">

| Shape | Requests/s at 160 | p95 TTFT at 160 | Mean EPP queue at 160 |
|---|---:|---:|---:|
| 256 in / 64 out | 165.1 | 569 ms | 47 ms |
| 512 in / 128 out | 88.4 | 689 ms | 102 ms |
| 1024 in / 128 out | 84.9 | 761 ms | 91 ms |
| 512 in / 512 out | 27.2 | 6.0 s | 56 ms |
| 2048 in / 256 out | 40.0 | 2.4 s | 119 ms |

The sweep ran 20 s per concurrency point in a single pass, so read it as a shape finder rather than a precision measurement. The requests per second and p95 TTFT columns come from the sweep summaries in `data/capacity-sweeps/`, and the queue column comes from the endpoint-picker metrics recorded during that pass, written up in [`SWEEP-NOTES.md`](data/capacity-sweeps/SWEEP-NOTES.md).

**Why it matters.** This is how every operating point below was chosen. Consolidation runs below the knee, and the saturation scenarios run above it on purpose. A platform team runs this same sweep once per hardware and model pair to place its own operating points. Data in [`data/capacity-sweeps/`](data/capacity-sweeps/).

## Consolidation without giving up latency

**What it proves.** Interactive workloads can share one GPU and hold an interactive latency target while more tenants arrive, here 300 ms p95 TTFT as a general working target.

**What we saw.** One premium tenant ran alone, a second premium tenant joined at 100 s, and a standard tenant joined at 200 s. p95 TTFT averaged 45 ms in the first phase, 47 and 51 ms in the second, and 67, 61, and 69 ms in the third. All 42,162 requests returned HTTP 200, and vLLM never queued a request.

<p>
<img src="assets/consolidation-ttft.svg" width="100%" alt="Rolling p95 TTFT holds between 30 and 80 ms as a second premium tenant joins at 100 seconds and a standard tenant joins at 200 seconds">
</p>

<img src="assets/consolidation-p95.svg" width="100%" alt="p95 TTFT by phase: 45 ms alone, 47 and 51 ms with two premium tenants, and 67 to 69 ms with a standard tenant added, all far under the 300 ms objective">

**Why it matters.** Consolidation is a cost decision. Each tenant added moved the objective by tens of milliseconds rather than breaking it, and flow control is the insurance if a spike pushes the pool past capacity.

*Three-phase consolidation run, 2026-07-27. Noisy sinusoidal arrivals, 300 s per repeat, one stabilization pass plus three counted repeats, 42,162 requests, zero non-200. Data in [`data/consolidation/`](data/consolidation/).*

## Service tiers under mixed load

**What it proves.** When the pool saturates, priority decides who waits. Premium stays ahead while standard absorbs the queue.

**What we saw.** Standard traffic surged past what the GPU could absorb. vLLM ran a full batch of 128 with up to 54 requests waiting, so the pool was genuinely past capacity. The p50 TTFT averaged 41 ms across the premium tenants and 379 ms across the standard tenants. Both non-200 responses in the run landed on a standard tenant.

<p>
<img src="assets/priority-traffic.svg" width="49%" alt="Standard class surges to about 160 in-flight requests while premium holds near 40">
<img src="assets/priority-ttft.svg" width="49%" alt="During saturation the standard p95 TTFT rises toward 900 ms while premium settles lower">
</p>

**Why it matters.** A latency-sensitive product keeps its experience through a surge it did not cause. That is what makes tiering and SLA commitments enforceable on shared capacity.

*Noisy priority run, 2026-07-24. Three counted repeats, 300 s each, 53,399 requests, 2 non-200. Data in [`data/priority/`](data/priority/).*

## Batch isolation under surge

**What it proves.** Batch traffic cannot displace interactive traffic, even when it dominates the arrival rate.

**What we saw.** Batch ramped to about three times the interactive arrival rate. Mean queue time averaged 202 ms for batch against 64 ms for premium and 66 ms for standard, consistent across all three repeats. Both non-200 responses in the run landed on the batch tenant.

<p>
<img src="assets/batch-traffic.svg" width="49%" alt="Batch arrival rate ramps to roughly triple the interactive classes at 150 seconds">
<img src="assets/batch-ttft.svg" width="49%" alt="Batch p95 TTFT runs roughly 300 ms above premium and standard throughout the surge">
</p>

<img src="assets/batch-queue.svg" width="100%" alt="Mean EPP queue time bars: premium 64 ms, standard 66 ms, batch 202 ms">

**Why it matters.** Overnight document and report pipelines can fill the same GPUs that serve interactive traffic by day, without risking interactive SLOs. That is what lets a consolidated pool run hot.

*Clean pressure pass, 2026-07-21. Three counted repeats, 53,954 requests, 2 non-200. Data in [`data/batch-isolation/`](data/batch-isolation/).*

## The first pressure campaign

The first campaign, on 2026-07-21, pushed one endpoint to doubled load and served every request at 513 to 606 ms p95 TTFT. It showed the mechanism working end to end at the first configuration we tried. Tuning the configuration brings that number down, which is what the runs above show at their chosen operating points. The report and the run-level data from that campaign are kept here so the progression is visible.

[`report/flow-control-under-pressure.html`](report/flow-control-under-pressure.html) is the written report, and the PDF beside it renders in the browser. Run-level and per-tenant rollups are in [`data/first-pressure-campaign/`](data/first-pressure-campaign/).

## Ordering is not occupancy

Fairness divides a band's capacity among the tenants inside it. Priority decides which band is served first. Neither one limits how much of the running batch a tenant holds, which is what sets latency once the pool is saturated. [`docs/fairness-vs-isolation.md`](docs/fairness-vs-isolation.md) walks a request through the mechanism, shows a matched pair that isolates the effect, and covers how to size the batch and the queue limits.

## What we ran

<img src="assets/evidence-board.svg" width="100%" alt="Every run in the campaign, what it proves, its headline number, and whether it is published">

## In progress

The same-band fairness scenario is being rerun as a matched pair, once with all tenants in one band and once with the burster moved down, so the two mechanisms can be read against each other on identical traffic.

## Tuning map

[`docs/tuning-map.md`](docs/tuning-map.md) maps the question you are asking onto the one mechanism that answers it, from sizing the active batch to bounding a burst, and states what each mechanism will not do. Drawn from the runs in this repo.

<img src="assets/tuning-map.svg" width="100%" alt="Decision map from question to mechanism: active batch limit, fairness, priority bands, saturation detector, queue limits, and replicas, each with its limit">

## Learn flow control

**[Open the interactive explainer](https://alexagriffith.github.io/flow-control-benchmarks/learn/flow-control-journey.html)**

Six stops take you from the cost problem to the dispatch path, the saturation gate, and what the policy does under pressure, ending in a playground where you drive the load yourself. It autoplays, and it runs in light or dark. Source is at [`learn/flow-control-journey.html`](learn/flow-control-journey.html).

[The written explainer](https://alexagriffith.github.io/flow-control-benchmarks/learn/flow-control.html) is the same material as a page to read rather than click through.

Both are single self-contained files written against the upstream llm-d Endpoint Picker documentation. The links above are served by GitHub Pages from this repo, and either file also runs if you download it and open it locally. Charts inside the explainer that carry measured numbers say so, and the curves around them are redrawn for teaching rather than plotted from the samples.

## Policy auditability

The policy is verifiable from four records in four layers, from the request header to the GPU runtime.

| Layer | What it records | Why it matters |
|---|---|---|
| Request headers | `x-gateway-inference-objective`, `x-gateway-inference-fairness-id` | Traffic is classified by trusted platform policy, not by a hidden route |
| InferenceObjective | Premium 100, standard 0, batch -10 | Business priority maps to a concrete platform resource |
| Endpoint Picker queues | Priority band, fairness ID, queue duration | Queueing can be explained by tenant and traffic class |
| vLLM metrics | Running and waiting requests | Shows when the GPU runtime is actually saturated |

## Methodology

Traffic for the saturation scenarios is noisy and sinusoidal on purpose, closer to production arrival patterns than a flat synthetic load, and each traffic chart shows the pattern that ran. We measured TTFT client side, from request start to first streamed token, through the gateway. Each scenario ran 300 s of active traffic with repeats, warmup and stabilization excluded. Every request is logged individually, and every chart is drawn from that per-request data. Prompts targeted 512 input tokens with fixed response lengths, a benchmark control, so end-to-end latency here is not a production prediction. TTFT is the comparable metric.

Each result comes from its own accepted campaign. [`RUNLOG.md`](RUNLOG.md) lists them with the bar each one had to clear.

## Environment

Numbers move with the build as well as the hardware, so the exact versions and settings behind every run are recorded here.

| | |
|---|---|
| Model | `openai/gpt-oss-20b` |
| GPU | One NVIDIA H100 80GB HBM3 per endpoint, tensor parallel 1 |
| Kubernetes | v1.36.1 |
| Serving runtime | `registry.redhat.io/rhaii/vllm-cuda-rhel9@sha256:ad06abf3bb5235ebb5b2df84cd1b9fd09e823f0ff2eebfc82bb4590275ccfe0b` |
| Endpoint picker | `registry.redhat.io/rhoai/odh-llm-d-inference-scheduler-rhel9@sha256:bddf686d6eaf1a607e1c697f58165d685944607cb4629648f27e56b2884e3de0`, deployment version label 0.7.0 |
| KV cache component | `registry.redhat.io/rhoai/odh-llm-d-kv-cache-rhel9@sha256:db4b79a17194574aeae3e702eb2740485c95f160166d2ea7b6cbab0a40cfe9e9` |

vLLM arguments: `--tensor-parallel-size 1 --max-model-len 32768 --max-num-batched-tokens 8192 --max-num-seqs 128 --gpu-memory-utilization 0.90`. Two runs used `--max-num-seqs 64` and are labeled where they appear.

Endpoint picker configuration: `flowControl` enabled in `featureGates`, `defaultRequestTTL: 60s`, `maxBytes: 10737418240`, no per-band `maxRequests`. Three priority bands at 100, 0, and -10, each using `round-robin-fairness-policy` and `fcfs-ordering-policy`. Saturation detector: `queueDepthThreshold: 4` and `kvCacheUtilThreshold: 0.8`, with `queueDepthThreshold: 1` in the runs that say so. Scheduling profile: `queue-scorer` at weight 2, `kv-cache-utilization-scorer` at weight 2, `prefix-cache-scorer` at weight 3.

## Repo layout

| Path | Contents |
|---|---|
| [`data/`](data/) | Summaries, configs, and per-request samples from the accepted runs |
| [`assets/`](assets/) | Every chart, generated from the data |
| [`pipeline/`](pipeline/) | The benchmark runner and the chart generator |
| [`report/`](report/) | The first campaign report, HTML and PDF |
| [`learn/`](learn/) | The flow control explainer page |
| [`RUNLOG.md`](RUNLOG.md) | Each campaign, its verdict, and the reason |

## Reproducing it

`pipeline/benchmark_v3.py` drives the traffic and writes per-request samples, and `pipeline/gen_charts.py` redraws every chart from those samples. Point the runner at an llm-d gateway with priority bands configured as premium 100, standard 0, and batch -10. See [`pipeline/README.md`](pipeline/README.md).
